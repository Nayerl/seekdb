# AMD hipVS HNSW 提交材料

先阅读 [提交及复现说明](docs/gpu-hnsw-build/SUBMISSION.md) 和
[2026-10-31 入口、部署与完整重建验收](docs/gpu-hnsw-build/ENTRY_AUDIT_20261031.md)。

完整工程：https://github.com/sevenmiles666/psfseekdb ，分支 competition/amd-hipvs-build。
本包包含相关源码、测试、说明、历史与本轮证据；构建与 Git 历史哈希核验使用完整仓库。
最新完整编译及安装 SQL 验收的源码提交为 b35b7d4c824d13c71737332b1c5ce333b5f1ff28。
本包 17 个实现/构建/验证文件与该版本逐文件 SHA-256 一致；另一个 copy.sh 在此后
补充了配置判断并通过真实 GPU 产物部署和失败/CPU 配置检查，详见 release-source-provenance.json。
最终提交另含文档与证据，未声称它再次从空目录编译过 C++。

competition-changes.patch 相对赛事基线 5bce9e06d1281347ad61344e4b01fab9158c58a2，
已用该基线的独立 Git index 执行 git apply --cached --check。补丁不包含 ZIP 和自身校验文件。
文件清单及哈希见 PACKAGE_MANIFEST.json。包内保留 Linux LF 换行。

新 GPU 构建可用 OB_BUILD_CUVS=ON 或 OB_BUILD_HIPVS=ON。标准 server 安装组件和
copy.sh 已包含 worker/bridge；仍需 hipVS/ROCm 运行依赖。完整 CPack 打包和 Bazel GPU
构建没有通过验收，具体限制见报告。实测加速倍数不能代替官方成绩。
