# seekdb hipVS 提交材料包

先阅读 docs/gpu-hnsw-build/SUBMISSION.md。
完整工程：https://github.com/sevenmiles666/psfseekdb ，分支 competition/amd-hipvs-build。
本包包含实现相关源码、测试、运行说明、原始验证记录和相对赛事基线的补丁。
它不是独立的完整 seekdb 工程；构建请克隆完整仓库。
competition-changes.patch 对应基线 5bce9e06d1281347ad61344e4b01fab9158c58a2。
在基线的干净工作树运行 git apply --check 后，可用 git apply 导入代码和材料（不含本 zip）。
所有归档文件来自已暂存的 Git 内容，保留 Linux LF 换行；SHA-256 见 PACKAGE_MANIFEST.json。
无 GPU 时，可在本包根目录运行 SUBMISSION.md 中的 Python 回归及新证据核验命令。
